﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session5Assignments
{
    ///<summary>
    ///Sum of Diagonal elements of multi dimensional array
    ///</summary>
    class SumOfDiaginalElements
    {
        static void Main()
        {
            int[,] num = new int[3, 3];
            Console.WriteLine("Enter Array Elements : ");
            for(int i = 0; i < 3; i++)
            {
                for(int j = 0; j < 3 ;j++ )
                {
                    num[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine(" Array Elements : ");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t", num[i, j]);
                }
                Console.WriteLine();
            }

            int sum = 0;
           // Console.WriteLine("Sum of diagonal Elements : ");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if(i == j)
                    {
                        sum = sum + num[i, j];
                    }
                }
                
            }
            Console.WriteLine("Sum of Diagonal Elements = {0} ",sum);
            Console.ReadLine();
        }
    }
}
