﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session5Assignments
{
    class SumOfRowElements
    {
        static void Main()
        {
            int[,] a = new int[3, 3];
            Console.WriteLine("Enter Array Elements : ");
            for(int i = 0; i < 3; i++)
            {
                Console.WriteLine("Enter elements of {0}th Row : ", i);
                for(int j = 0; j < 3; j++)
                {
                    a[i, j] =Convert.ToInt32( Console.ReadLine());
                }
                Console.WriteLine();
            }
            
            for (int i = 0; i < 3; i++)
            {
                int sum = 0;
                for (int j = 0; j < 3; j++)
                {
                    
                    sum = sum + a[i, j];
                }
                Console.WriteLine("Sum of {0}th row = {1} ", i, sum);
            }
            Console.ReadLine();
        }
    }
}
