﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session5Assignments
{
    class SumOfSingleDimArray
    {
        static void Main()
        {
            int[] num = new int[5] { 1, 2, 3, 4, 5 };
            Console.WriteLine("Nums array : ");
            foreach(int temp in num)
            {
                Console.WriteLine(temp);
            }

            int sum = 0;
            for (int i = 0; i < num.Length; i++)
            {
                sum = sum + num[i];
            }
            Console.WriteLine("Sum of elements of nums array = {0} ", sum);
            Console.ReadLine();
        }
    }
}
