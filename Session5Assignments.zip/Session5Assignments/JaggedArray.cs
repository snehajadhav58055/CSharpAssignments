﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session5Assignments
{
    ///<summary>
    ///Search elements from Jagged array
    ///</summary>
    class JaggedArray
    {
        static void Main()
        {
            Console.WriteLine();
            int[][] num = new int[2][];
            num[0] = new int[]{1,2,3,4};
            num[1] = new int[]{5,6,7};

            foreach(int temp in num[0])
            {
                Console.Write("\t{0}", temp);
            }
            Console.WriteLine();


            foreach (int temp in num[1])
            {
                Console.Write("\t{0}", temp);
            }
            Console.WriteLine();

            Console.WriteLine("Enter number to be Searched : ");
            int n = Convert.ToInt32(Console.ReadLine());
            bool flag = true;

            foreach (int i in num[0])
            {
                if(i == n)
                {
                    flag = false;
                }
            }
                foreach(int j in num[1])
                {
                    if(j == n)
                    {
                        flag = false;
                    }
                }
            
            if (flag)
            {
                Console.WriteLine("Number not found...");
            }
            else
            {
                Console.WriteLine("Number found.");
            }

            Console.ReadLine();
        }
    }
}
