﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session4Assignment
{
    ///<summary>
    ///Displaying odd numbers using do while loop
    ///</summary>
    class OddNoUsingDoWhile
    {
        static void Main()
        {
         
            Console.WriteLine("Odd Numbers from 1 to 50 : ");
            int i = 1;
           // int n = 50;
            do
            {
                
                if (i % 2 != 0)
                {
                    Console.WriteLine(i);

                }
                i++;
            } while (i <= 50);
            Console.ReadLine();
        }
    }
}
