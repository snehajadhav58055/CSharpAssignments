﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session4Assignment
{
    class OddNoFromArrayUsingForeach
    {
        static void Main()
        {
            int[] num = new int[50];
          //  Console.WriteLine("Array Elements :  ");
            for(int i = 1; i < num.Length; i++)
            {
                num[i] = i;
            }
            Console.WriteLine("Odd Array Elements :  ");

            foreach (int temp in num)
            {
                if(temp % 2 != 0)
                {
                    Console.WriteLine(temp);
                }
            }
            Console.ReadLine();
        }
    }
}
