﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session4Assignment
{
    class TableUsingFor
    {
        static void Main()
        {
            Console.WriteLine("Enter number to print Table : ");
            int n = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Table of {0} is : ", n);
            for(int i = 1; i <= 10; i++)
            {
                Console.WriteLine("{0} * {1} = {2} ", n, i, n * i);

            }
            Console.ReadLine();
        }
    }
}
