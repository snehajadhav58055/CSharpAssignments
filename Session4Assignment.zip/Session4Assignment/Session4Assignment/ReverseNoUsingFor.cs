﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session4Assignment
{
    class ReverseNoUsingFor
    {
        static void Main()
        {
            Console.WriteLine("Numbers in Reverse Order : ");
            for(int i = 50; i >= 1; i--)
            {
                Console.WriteLine(i);
            }
            Console.ReadLine();
        }
    }
}
