﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7Assignments
{
    ///<summary>
    ///display student values using enum and struct
    ///</summary>
    class StudentMain
    {
        static void Main()
        {
            Student st = new Student(1,"Sneha",'F',8623828748);
            Console.WriteLine(st.display());
            Console.ReadLine();
        }
    }
}
