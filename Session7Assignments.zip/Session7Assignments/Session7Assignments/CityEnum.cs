﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7Assignments
{
    public enum CityEnum
    {
        Pune = 20,Aurangabaad = 024,Jabalpur = 076
    };


}
