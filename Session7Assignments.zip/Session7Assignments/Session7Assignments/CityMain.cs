﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7Assignments
{
    class CityMain
    {
        static void Main()
        {
            foreach(string cities in Enum.GetNames(typeof(CityEnum)))
            {
                Console.WriteLine(cities);
            }

            foreach (int code in Enum.GetValues(typeof(CityEnum)))
            {
                Console.WriteLine(code);
            }
            Console.ReadLine();
        }
    }
}
