﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session1Assignments
{
    ///<summary>
    ///Area of Circle using Constants
    ///</summary>
    class AreaOfCircleUsingConstants
    {
        static void Main()
        {
          
            const double PI = 3.14;
            double area;
            int r = 10;
            area = PI * r * r;
            Console.WriteLine("Area of circle = {0}", area);
            Console.ReadLine();
        }
    }
}
