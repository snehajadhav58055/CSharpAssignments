﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session1Assignments
{

    ///<summary>
    ///Currency Conversion(Ruppes-Dollar) Vice versa
    ///</summary>
    class DollarToRsConversion
    {
        static void Main()
        {

            Console.WriteLine("Enter dollar amount : ");
            double dollar = Convert.ToInt64(Console.ReadLine());

            double rs;
            rs = dollar * 71.76;
            
            Console.WriteLine("{0} Dollar = {1} Rupees = ",dollar, rs);
            Console.WriteLine("{0} Rupees = {1} Dollar = " ,rs,(rs / dollar));
            Console.ReadLine();
        }
       
    }
}
