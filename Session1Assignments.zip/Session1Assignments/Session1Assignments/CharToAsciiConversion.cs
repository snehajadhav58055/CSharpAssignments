﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session1Assignments
{
    ///<summary>
    ///Character to ASCII Conversion
    ///</summary>
    class CharToAsciiConversion
    {
        static void Main()
        {
           
            char ch = 'A';
            
                Console.WriteLine("Ascii value of "+ch+"={0}",(int)ch);
            int n = Convert.ToInt32(ch);
            Console.WriteLine("Character value of "+n+"={0}",(char)n);
            Console.ReadLine();
        }
    }
}
