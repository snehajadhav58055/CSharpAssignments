﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session8Assignments
{
    public sealed class Pen
    {
        public void StartWriting()
        {
            Console.WriteLine("Start Writing...");
        }

        public void StopWriting()
        {
            Console.WriteLine("Stop Writing...");
        }

        static void Main()
        {
            Pen p = new Pen();
            p.StartWriting();
            p.StopWriting();

            Console.ReadLine();
        }
    }
}
