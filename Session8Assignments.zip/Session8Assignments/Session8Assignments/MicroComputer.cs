﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session8Assignments
{
    class MicroComputer : Computer
    {
        public void dispMicroComp()
        {
            Console.WriteLine("Micro Computer");
        }
    }
}
