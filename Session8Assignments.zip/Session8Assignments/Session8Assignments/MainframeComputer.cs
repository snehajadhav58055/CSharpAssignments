﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session8Assignments
{
    class MainframeComputer : Computer
    {
        public void dispMainframeComp()
        {
            Console.WriteLine("Mainframe Computer");
        }
    }
}
