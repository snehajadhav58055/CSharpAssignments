﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session8Assignments
{/// <summary>
/// Bank Functions
/// </summary>
    class BankMain
    {
        static void Main()
        {
            Console.WriteLine("=========SAVING ACCOUNT=========");
            Console.WriteLine();

            SavingAccount save = new SavingAccount();
            Console.WriteLine("Enter Amount To Deposit : ");
            double damt = Convert.ToDouble(Console.ReadLine());
            save.Deposit(damt);

            Console.WriteLine("Enter Amount To Withdraw : ");
            double wamt = Convert.ToDouble(Console.ReadLine());

            save.Withdraw(wamt);

            Console.WriteLine("=========CURRENT ACCOUNT=========");
            Console.WriteLine();

            CurrentAccount curr = new CurrentAccount();
            Console.WriteLine("Enter Amount To Deposit : ");
            double d = Convert.ToDouble(Console.ReadLine());

            curr.Deposit(d);

            Console.WriteLine("Enter Amount To Withdraw : ");
            double w = Convert.ToDouble(Console.ReadLine());

          curr.Withdraw(w);
            Console.ReadLine();
        }
    }
}
