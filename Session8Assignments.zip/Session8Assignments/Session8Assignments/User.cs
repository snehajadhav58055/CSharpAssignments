﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session8Assignments
{/// <summary>
/// Forum-Requirement
/// </summary>
    class User
    {
        private long id;//private attributes
        private string name;
        private string emailId;
        private string dateOfBirth;

        public long Id { get; set; }//properties
        public string Name { get; set; }
        public string EmailId { get; set; }
        public string DateOfBirth { get; set; }

        public User() // default Constructor
        {

        }

        public User(long id,string name,string emailId,string dateOfBirth) //parameterized constructor
        {
            this.id = id;
            this.name = name;
            this.emailId = emailId;
            this.dateOfBirth = dateOfBirth;


        }

        public override string ToString()//Overrides ToString()
        {
            return $"User ID : {id} \n User Name : {name} \n Email Id : {emailId} \n Date Of Birth : {dateOfBirth}";
        }

        public static bool CheckDuplicateEmail(List<User> users,string mail)//Validating duplicate emails
        {
            foreach(User temp in users)
            {
                if(temp.emailId == mail)
                {
                    return true;
                }
            }
            return false;
        }

        static void Main()
        {
            List<User> userList = new List<User>();
            int choice;
            do
            {
                Console.WriteLine("Enter User Id : ");
                long uid = Convert.ToInt64(Console.ReadLine());

                Console.WriteLine("Enter User Name : ");
                string unm = Console.ReadLine();

                Console.WriteLine("Enter Email Id : ");
                string email = Console.ReadLine();

                bool result = CheckDuplicateEmail(userList, email);
                while (result)
                {
                    Console.WriteLine("Sorry.Email Id Not Available");
                    email = Console.ReadLine();
                    result = CheckDuplicateEmail(userList, email);
                }

                Console.WriteLine("Enter Date of birth : ");
                string dob = Console.ReadLine();

                Console.WriteLine("===========User Details==========");
                Console.WriteLine();
                User user = new User(uid, unm, email, dob);

                Console.WriteLine(user.ToString());
                Console.WriteLine("Do You want to add more Users : ");
                Console.WriteLine("1.Add \n 2.Exit");
                choice = Convert.ToInt32(Console.ReadLine());

                userList.Add(user);
            } while (choice != 2);

            Console.ReadLine();

        }
    }
}
