﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session8Assignments
{
   abstract class Computer
    {
        public void BootUp()
        {
            Console.WriteLine("BootUp Function of Computer Class");
        }

        public void ShutDown()
        {
            Console.WriteLine("ShutDown function of Computer class");
        }
    }
}
