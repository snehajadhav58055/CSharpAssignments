﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session8Assignments
{
    /// <summary>
    /// Hotel-Requirement
    /// </summary>
    class Room
    {
        private int room_number;
        private int floor;
        private string type;
        private int capacity;
        private DateTime bookedDate;
        private double price;

        public Room()
        {
            Console.WriteLine("Default Constructor Of Room");
        }

        public Room(int room_number, int floor, string type, int capacity, DateTime bookedDate, double price)
        {
            this.room_number = room_number;
            this.floor = floor;
            this.type = type;
            this.capacity = capacity;
            this.bookedDate = bookedDate;
            this.price = price;

        }

        public int number
        {
            get
            {
                return room_number;
            }

            set
            {
                room_number = value;
            }
        }

        public int floorNo
        {
            get
            {
                return floor;
            }

            set
            {
                floor = value;
            }
        }

        public string TType
        {
            get
            {
                return type;
            }

            set
            {
               type = value;
            }
        }

        public int Capacity
        {
            get
            {
                return capacity;
            }

            set
            {
                capacity = value;
            }
        }

        public DateTime BookingDate
        {
            get
            {
                return bookedDate;
            }

            set
            {
                bookedDate = value;
            }
        }

        public double Price
        {
            get
            {
                return price;
            }

            set
            {
                price = value;
            }
        }

        public override string ToString()
        {
            return $"Room Number = {room_number} \n Floor = {floor} \n  Type = {type} \n Capacity = {capacity} \n" +
                $"Booking Time = {bookedDate} \n Price = Rs {price}";
        }

        static void Main()
        {
            
            Console.WriteLine("Enter Room Number : ");
            int rno =Convert.ToInt32( Console.ReadLine());

            Console.WriteLine("Enter Floor : ");
            int fno = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Room Type : ");
            string ty = Console.ReadLine();

            Console.WriteLine("Enter Room Capacity : ");
            int cap = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Room Booking Time : ");
            DateTime booking =Convert.ToDateTime(Console.ReadLine());

            Console.WriteLine("Enter Room Rent : ");
            int pr = Convert.ToInt32(Console.ReadLine());

            Room room = new Room(rno,fno,ty,cap,booking,pr);
          
            Console.WriteLine(room.ToString());
            Console.ReadLine();
        }
    }
}
