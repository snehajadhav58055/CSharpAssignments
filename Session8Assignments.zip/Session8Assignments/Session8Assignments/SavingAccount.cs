﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session8Assignments
{/// <summary>
/// savingAccount implements IBakAccount Interface
/// 
/// </summary>
    class SavingAccount : IBankAccount
    {
        double bal = 10000;

        public void Deposit(double amount)
        {
           
            bal = bal + amount;
            Console.WriteLine($"Your Balance After Deposit is Rs.{bal} ");

        }

        public void Withdraw(double amount)
        {
    
            bal = bal - amount;
            Console.WriteLine($"Your Balance After Withdraw is Rs.{bal} ");

        }
    }
}
