﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session8Assignments
{
    /// <summary>
    /// CurrentAccount implements IBakAccount Interface
    /// 
    /// </summary>
    class CurrentAccount : IBankAccount
    {
        double bl = 10000;
        public void Deposit(double amount)
        {
            
            bl = bl + amount;
            Console.WriteLine($"Your Balance After Deposit is Rs.{bl} ");

        }

        public void Withdraw(double amount)
        {
            bl = bl - amount;
            Console.WriteLine($"Your Balance After Withdraw is Rs.{bl} ");

        }

    }
}
