﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSTLib
{
    public class GST
    {
        double Amount;
        double GstPer;

        public static double CalculateGST(double Amount,double GstPer,out double TotAmt)
        {
            TotAmt = (Amount * (GstPer / 100));

            return Amount + TotAmt ;
        }

        //public GST(int Amount,double GstPer)
        //{
        //    this.Amount = Amount;
        //    this.GstPer = GstPer;
        //}
    }
}
