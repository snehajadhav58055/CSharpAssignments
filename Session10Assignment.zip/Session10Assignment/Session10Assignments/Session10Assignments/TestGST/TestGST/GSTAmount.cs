﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSTLib;

namespace TestGST
{
    class GSTAmount
    {
        static void Main()
        {
            Console.WriteLine("Enter Amount : ");
            double Amt = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter GST Percentage : ");
            double per = Convert.ToDouble(Console.ReadLine());

            double total;

            GST g = new GST();
            Console.WriteLine($"Total Amount with {per}% GST : {GST.CalculateGST(Amt, per, out total)}");

            Console.WriteLine($"Total GST on {Amt} = Rs.{total}");
            Console.ReadLine();
        }
    }
}
