﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session10Assignments
{
    /// <summary>
    /// Extension function 
    /// </summary>
    public static class PositiveNegative
    {

        public static void IsPositive(this int i, int val)
        {


            if (val > 0)
            {
                Console.WriteLine("Current Value is Positive {0}",val = val + i);
            }
            else
            {


                Console.WriteLine("Number is Negative");
            }




        }

    }
    class TestPosNeg
    {
        static void Main()
        {
            int i = 40;
            Console.WriteLine();
            int val = 5;
            Console.WriteLine($"Current Value = {i} and Parameter value = {val}");

            i.IsPositive(val);

            Console.ReadLine();
        }
    }

}  



