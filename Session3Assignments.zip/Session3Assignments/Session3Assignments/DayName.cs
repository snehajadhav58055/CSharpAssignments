﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session3Assignments
{
    class DayName
    {
        static void Main()
        {
            Console.WriteLine("Enter Day number : ");
            int choice = Convert.ToInt32(Console.ReadLine());

            switch(choice)
            {
                

                case 1:
                    Console.WriteLine("1 = MONDAY");
                    break;
                case 2:
                    Console.WriteLine("2 = TUESDAY");
                    break;
                case 3:
                    Console.WriteLine("3 = WEDNESDAY");
                    break;
                case 4:
                    Console.WriteLine("4 = THURSDAY");
                    break;
                case 5:
                    Console.WriteLine("5 = FRIDAY");
                    break;
                case 6:
                    Console.WriteLine("6 = SATURDAY");
                    break;
                case 7:
                    Console.WriteLine("7 = SUNDAY");
                    break;
                default: Console.WriteLine("Invalid Choice...");
                    break;


            }
            Console.ReadLine();
        }
    }
}
