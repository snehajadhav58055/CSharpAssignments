﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session3Assignments
{
    class MajorOrMinor
    {
        static void Main()
        {
            Console.WriteLine("Enter Age of a Person : ");
            int age =Convert.ToInt32(Console.ReadLine());

            if(age < 18)
            {
                Console.WriteLine("Minor Person..");
            }
            else
            {
                Console.WriteLine("Major Person..");
            }

            Console.ReadLine();
        }
    }
}
