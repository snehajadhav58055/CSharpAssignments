﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session3Assignments
{
    class MajorMinorUsingTernary
    {
        static void Main()
        {
            Console.WriteLine("Enter Age of a Person : ");
            int age = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(age > 18 ? "You are Major Person" : "You are Minor Person");

            Console.ReadLine();
        }
    }
}
