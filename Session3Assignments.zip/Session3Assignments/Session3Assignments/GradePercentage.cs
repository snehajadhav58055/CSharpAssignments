﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session3Assignments
{
    ///<summary>
    ///Displaying Grade of student as per marks
    ///</summary>
    class GradePercentage
    {
        static void Main()
        {

          
            
            Console.WriteLine("Enter Your Percentage : ");
            int per = Convert.ToInt32(Console.ReadLine());

            if(per >= 80)
            {
                Console.WriteLine("You are passed with A Grade..");
            }
            else if(per < 80 && per >= 60)
            {
                Console.WriteLine("You are passed with B Grade..");

            }
            else if (per < 60 && per >= 40)
            {
                Console.WriteLine("You are passed with C Grade..");

            }
            else
            {
                Console.WriteLine("You are Failed..");

            }

            Console.ReadLine();
        }
    }
}
