﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session3Assignments
{
    class GradePercentage
    {
        static void Main()
        {
            Console.WriteLine("Enter Your Percentage : ");
            int per = Convert.ToInt32(Console.ReadLine());

            if(per >= 80)
            {
                Console.WriteLine("You are passed with Distiction..");
            }
            else if(per < 80 && per >= 60)
            {
                Console.WriteLine("You are passed with First Class..");

            }
            else if (per < 60 && per >= 40)
            {
                Console.WriteLine("You are passed with Second Class..");

            }
            else
            {
                Console.WriteLine("You are Failed..");

            }

            Console.ReadLine();
        }
    }
}
