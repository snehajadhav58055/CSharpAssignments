﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session6Assignment
{
    ///<summary>
    ///Calculate factorial of number using function
    ///</summary>
    class FactorialUsingFunc
    {
        public static void fact(int n)
        {
            int facto = 1;
           
                while(n > 0)
                {
                    facto = facto * n--;

                }
            Console.WriteLine("Factorial = {0} ", facto);

        }

        static void Main()
        {
            Console.WriteLine("Enter Number : ");
            int n =Convert.ToInt32( Console.ReadLine());
            fact(n);

            Console.ReadLine();
        }
    }
}
