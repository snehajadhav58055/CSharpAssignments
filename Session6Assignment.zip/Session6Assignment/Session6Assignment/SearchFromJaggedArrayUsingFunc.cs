﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session6Assignment
{
    class SearchFromJaggedArrayUsingFunc
    {
        public static void search(int n)
        {
           
            int[][] num = new int[2][];
            num[0] = new int[4] { 1, 2, 3, 4 };
            num[1] = new int[3] { 5, 6, 7 };
           

            bool flag = true;

            foreach (int x in num[0])
            {
                if (n == x)
                {
                    flag = false;
                }

            }

            foreach (int x in num[1])
            {
                if (n == x)
                {
                    flag = false;
                }

            }

            if(flag)
            {
                Console.WriteLine("Element {0} not found", n);
            }
            else
            {
                Console.WriteLine("Element {0} found", n);

            }
        }
        static void Main()
        {
            int[][] num = new int[2][];
            num[0] = new int[4] { 1, 2, 3, 4 };
            num[1] = new int[3] { 5, 6, 7 };
            Console.WriteLine("Given array : ");

            foreach (int x in num[0])
            {
                Console.Write("\t{0}",x);

            }
            Console.WriteLine();

            foreach (int y in num[1])
            {
                Console.Write("\t{0}",y);

            }
            Console.WriteLine();

            Console.WriteLine("Enter Element to be searched : ");
            int found = Convert.ToInt32(Console.ReadLine());
            search(found);
           
            Console.ReadLine();
        }
    }
}
