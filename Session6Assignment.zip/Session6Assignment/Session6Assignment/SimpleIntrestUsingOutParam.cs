﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session6Assignment
{
    ///<summary>
    ///Program to find Simple Intrest using Out parameter
    ///</summary>
    class SimpleIntrestUsingOutParam
    {
        public static double Intrest(int p, int n , int r,out double amt)
        {

            double SI = (p * n * r) / 100;
            Console.WriteLine("Simple Intrest = Rs.{0} ", SI);

            amt = p + SI;

            return amt;
        }

        static void Main()
        {
            Console.WriteLine("Enter Principal Amount : Rs.");
            int p = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Time Duration : ");
            int n = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Rate of Intrest : ");
            int r = Convert.ToInt32(Console.ReadLine());

            double amt;
            Console.WriteLine("Total Payable Amount = Rs.{0} ",Intrest(p, n, r,out amt));

            Console.ReadLine();
        }
    }
}
