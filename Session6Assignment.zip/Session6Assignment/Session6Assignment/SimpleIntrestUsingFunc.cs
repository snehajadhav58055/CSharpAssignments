﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session6Assignment
{
    class SimpleIntrestUsingFunc
    {
        public static void Intrest(int p,int n,int r)
        {
            double SI = (p * n * r) / 100;
            Console.WriteLine("Simple Intrest = Rs.{0} ", SI);
        }
        static void Main()
        {
            Console.WriteLine("Enter Principal Amount : Rs.");
            int p = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Time Duration : ");
            int n = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Rate of Intrest : ");
            int r = Convert.ToInt32(Console.ReadLine());

            Intrest(p, n, r);
            Console.ReadLine();
        }
    }
}
