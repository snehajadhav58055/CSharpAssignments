﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session6Assignment
{
    ///<summary>
    ///Program to calculate Gst amount using optional parameter
    ///</summary>
    class GstOptionalParam
    {
        public static void CalcGst(double amt,int GstPer = 1)
        {
            Console.WriteLine("GST Amount : ");
            amt = amt * 0.01;
            Console.WriteLine("Total Payable Amount :Rs.{0} ",amt);

        }

        static void Main()
        {
            Console.WriteLine("Enter Amount : ");
            int amt =Convert.ToInt32( Console.ReadLine());

            CalcGst(amt);

            Console.ReadLine();
        }
    }
}
